/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'FirstFonts2\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-arrows-rotate-solid': '&#xe905;',
		'icon-chess-board-solid': '&#xe906;',
		'icon-chess-solid': '&#xe907;',
		'icon-chess-rook-solid': '&#xe908;',
		'icon-chess-rook-regular': '&#xe909;',
		'icon-chess-queen-solid': '&#xe90a;',
		'icon-chess-queen-regular': '&#xe90c;',
		'icon-chess-pawn-solid': '&#xe90d;',
		'icon-chess-pawn-regular': '&#xe90e;',
		'icon-chess-knight-solid': '&#xe90f;',
		'icon-chess-knight-regular': '&#xe911;',
		'icon-chess-king-solid': '&#xe912;',
		'icon-chess-king-regular': '&#xe913;',
		'icon-chess-bishop-regular': '&#xe914;',
		'icon-chess-bishop-solid': '&#xe915;',
		'icon-face-smile-regular': '&#xe917;',
		'icon-trophy-solid': '&#xe918;',
		'icon-hand-point-down-regular': '&#xe919;',
		'icon-hand-point-up-regular': '&#xe91b;',
		'icon-play-solid': '&#xe91c;',
		'icon-repeat-solid': '&#xe91d;',
		'icon-burst-solid': '&#xe900;',
		'icon-icons8-baby-feet-96': '&#xe901;',
		'icon-icons8-push-pin-64_1': '&#xe902;',
		'icon-icons8-thumb-64': '&#xe903;',
		'icon-virus-covid-solid': '&#xe904;',
		'icon-droplet': '&#xe90b;',
		'icon-headphones': '&#xe910;',
		'icon-pacman': '&#xe916;',
		'icon-bullhorn': '&#xe91a;',
		'icon-spinner': '&#xe97a;',
		'icon-spinner3': '&#xe97c;',
		'icon-spinner6': '&#xe97f;',
		'icon-bug': '&#xe999;',
		'icon-fire': '&#xe9a9;',
		'icon-target': '&#xe9b3;',
		'icon-switch': '&#xe9b6;',
		'icon-power-cord': '&#xe9b7;',
		'icon-flag': '&#xe9cc;',
		'icon-cross': '&#xea0f;',
		'icon-radio-unchecked': '&#xea56;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
